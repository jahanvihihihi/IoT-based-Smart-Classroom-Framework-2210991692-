
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, '../Frontend')));

mongoose.connect('mongodb://127.0.0.1:27017/classroom');

const DataSchema = new mongoose.Schema({
  noise:Number,
  temperature:Number,
  time:{type:Date,default:Date.now}
});

const Data = mongoose.model('Data',DataSchema);

app.post('/data', async (req,res)=>{
  const d = new Data(req.body);
  await d.save();
  res.send("Saved");
});

app.get('/analytics', async (req,res)=>{
  const data = await Data.find();
  res.json(data);
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../Frontend/index.html'));
});

app.listen(3000,()=>console.log("Server running on http://localhost:3000"));

void setup() {
  Serial.begin(115200);
  Serial.println("Smart Classroom Simulation Started");
}

void loop() {

  // Simulated sensor values
  int noise = random(30, 90);
  float temperature = random(20, 35);
  int light = random(100, 800);
  int focus = random(40, 90);

  // Print JSON-like data (safe method)
  Serial.print("{ ");
  
  Serial.print("\"noise\": ");
  Serial.print(noise);
  Serial.print(", ");

  Serial.print("\"temperature\": ");
  Serial.print(temperature);
  Serial.print(", ");

  Serial.print("\"light\": ");
  Serial.print(light);
  Serial.print(", ");

  Serial.print("\"focus\": ");
  Serial.print(focus);

  Serial.println(" }");

  delay(2000);
}
